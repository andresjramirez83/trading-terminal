import {
  cancelAlpacaOrder,
  fetchAlpacaAccount,
  fetchAlpacaOrders,
  fetchAlpacaPositions,
  placeAlpacaOrder,
  updateAlpacaOrder,
  type AlpacaMode,
  type AlpacaOrderClass,
  type AlpacaSide,
} from "../../services/api";
import type {
  QuickOrderEstimate,
  QuickOrderState,
} from "../../components/chart/right-panel/workspaces/trading/TradingTypes";
import { getSharedTradeHistoryEngine } from "../history/TradeHistoryEngine";
import { roundToTick } from "../pricing/TickSizeManager";
import {
  cleanSymbol,
  isFilledOrder,
  normalizeAccount,
  normalizeFilledOrder,
  normalizeOpenOrder,
  normalizePosition,
  roundShares,
  validateQuickOrder,
} from "./execution/TradeExecutionMappers";
import {
  EMPTY_PERFORMANCE_SNAPSHOT,
  EMPTY_TRADING_ACCOUNT,
  type ClosePositionOptions,
  type FlattenPositionsResult,
  type SubmitQuickOrderResult,
  type TradeExecutionListener,
  type TradeExecutionSnapshot,
} from "./execution/TradeExecutionTypes";

export type {
  ClosePositionOptions,
  FlattenPositionsResult,
  SubmitQuickOrderResult,
  TradeConnectionStatus,
  TradeExecutionAction,
  TradeExecutionListener,
  TradeExecutionSnapshot,
  TradeExecutionStatus,
} from "./execution/TradeExecutionTypes";

export class TradeExecutionService {
  private mode: AlpacaMode;
  private snapshot: TradeExecutionSnapshot;
  private listeners = new Set<TradeExecutionListener>();
  private refreshTimer: number | null = null;
  private refreshInFlight: Promise<TradeExecutionSnapshot> | null = null;
  private queuedRefresh = false;
  private historyEngine = getSharedTradeHistoryEngine();

  constructor(mode: AlpacaMode = "paper") {
    this.mode = mode;

    this.snapshot = {
      mode,
      connectionStatus: "disconnected",
      status: "idle",
      action: "idle",
      loading: false,
      lastError: null,
      lastMessage: null,

      account: EMPTY_TRADING_ACCOUNT,
      positions: [],
      openOrders: [],
      filledOrders: [],
      tradeHistory: [],
      performance: EMPTY_PERFORMANCE_SNAPSHOT,

      rawAccount: null,
      rawPositions: [],
      rawOpenOrders: [],
      rawFilledOrders: [],

      updatedAt: null,
      refreshCount: 0,
    };
  }

  getSnapshot(): TradeExecutionSnapshot {
    return this.snapshot;
  }

  getMode(): AlpacaMode {
    return this.mode;
  }

  setMode(mode: AlpacaMode): void {
    if (this.mode === mode) return;

    this.mode = mode;
    this.setSnapshot({
      mode,
      connectionStatus: "reconnecting",
      lastMessage: `Switched to ${mode} mode.`,
    });

    this.queueRefresh();
  }

  subscribe(listener: TradeExecutionListener): () => void {
    this.listeners.add(listener);
    listener(this.snapshot);

    return () => {
      this.listeners.delete(listener);
    };
  }

  startPolling(intervalMs = 8000): void {
    this.stopPolling();

    this.setSnapshot({
      connectionStatus:
        this.snapshot.connectionStatus === "connected"
          ? "connected"
          : "connecting",
    });

    this.refreshTimer = window.setInterval(() => {
      this.queueRefresh();
    }, Math.max(3000, intervalMs));

    this.queueRefresh();
  }

  stopPolling(): void {
    if (this.refreshTimer != null) {
      window.clearInterval(this.refreshTimer);
      this.refreshTimer = null;
    }
  }

  queueRefresh(): void {
    if (this.refreshInFlight) {
      this.queuedRefresh = true;
      return;
    }

    this.refreshInFlight = this.refreshAll()
      .catch(() => this.snapshot)
      .finally(() => {
        this.refreshInFlight = null;

        if (this.queuedRefresh) {
          this.queuedRefresh = false;
          this.queueRefresh();
        }
      });
  }

  async refreshAll(): Promise<TradeExecutionSnapshot> {
    this.setSnapshot({
      status: "loading",
      action: "refreshing",
      loading: true,
      lastError: null,
      lastMessage: "Refreshing trading data...",
      connectionStatus:
        this.snapshot.connectionStatus === "connected"
          ? "connected"
          : "connecting",
    });

    try {
      const [rawAccount, rawPositions, rawOpenOrders, rawClosedOrders] =
        await Promise.all([
          fetchAlpacaAccount(this.mode),
          fetchAlpacaPositions(this.mode),
          fetchAlpacaOrders(this.mode, "open", true),
          fetchAlpacaOrders(this.mode, "closed", true),
        ]);

      const rawPositionsArray = Array.isArray(rawPositions) ? rawPositions : [];
      const rawOpenOrdersArray = Array.isArray(rawOpenOrders)
        ? rawOpenOrders
        : [];
      const rawClosedOrdersArray = Array.isArray(rawClosedOrders)
        ? rawClosedOrders
        : [];

      const filledOrders = rawClosedOrdersArray
        .filter(isFilledOrder)
        .map(normalizeFilledOrder);

      this.historyEngine.setFilledOrders(filledOrders);

      this.setSnapshot({
        status: "success",
        action: "idle",
        loading: false,
        connectionStatus: "connected",
        lastError: null,
        lastMessage: "Trading data refreshed.",

        account: normalizeAccount(rawAccount),
        positions: rawPositionsArray.map(normalizePosition),
        openOrders: rawOpenOrdersArray.map(normalizeOpenOrder),
        filledOrders,
        tradeHistory: this.historyEngine.getTradeHistory(),
        performance: this.historyEngine.getPerformance(),

        rawAccount,
        rawPositions: rawPositionsArray,
        rawOpenOrders: rawOpenOrdersArray,
        rawFilledOrders: rawClosedOrdersArray,

        updatedAt: Date.now(),
        refreshCount: this.snapshot.refreshCount + 1,
      });

      return this.snapshot;
    } catch (error) {
      this.setSnapshot({
        status: "error",
        action: "idle",
        loading: false,
        connectionStatus: "error",
        lastError: this.errorToMessage(error),
        lastMessage: null,
      });

      return this.snapshot;
    }
  }

  async submitQuickOrder(
    order: QuickOrderState,
    estimate: QuickOrderEstimate,
  ): Promise<SubmitQuickOrderResult> {
    const validationError = validateQuickOrder(order, estimate);

    if (validationError) {
      return this.failSubmit(validationError);
    }

    this.setSnapshot({
      status: "loading",
      action: "submitting-order",
      loading: true,
      lastError: null,
      lastMessage: "Sending order to Alpaca...",
    });

    const orderClass: AlpacaOrderClass | undefined = order.bracketEnabled
      ? "bracket"
      : undefined;

    const payload: any = {
      mode: this.mode,
      symbol: cleanSymbol(order.symbol),
      side: order.side as AlpacaSide,
      qty: estimate.estimatedShares,
      type: order.orderType,
      time_in_force: "day",
      extended_hours: Boolean(order.extendedHours),
      order_class: orderClass,
    };

    if (order.orderType === "limit") {
      payload.limit_price = roundToTick(order.limitPrice);
    }

    if (order.bracketEnabled && order.bracketTarget > 0) {
      payload.take_profit = {
        limit_price: roundToTick(order.bracketTarget),
      };
    }

    if (order.bracketEnabled && order.bracketStop > 0) {
      payload.stop_loss = {
        stop_price: roundToTick(order.bracketStop),
      };
    }

    try {
      const placedOrder = await placeAlpacaOrder(payload);

      this.setSnapshot({
        status: "success",
        action: "idle",
        loading: false,
        connectionStatus: "connected",
        lastError: null,
        lastMessage: "Order submitted to Alpaca.",
      });

      this.queueRefresh();

      return {
        ok: true,
        order: placedOrder,
      };
    } catch (error) {
      return this.failSubmit(this.errorToMessage(error));
    }
  }

  async closePositionShares(
    symbol: string,
    shares: number,
    options?: ClosePositionOptions,
  ): Promise<SubmitQuickOrderResult> {
    const safeSymbol = cleanSymbol(symbol);
    const closeShares = roundShares(shares);

    if (!safeSymbol || safeSymbol === "—") {
      return this.failSubmit("Symbol is required to close a position.");
    }

    if (closeShares <= 0) {
      return this.failSubmit("Close quantity must be greater than 0.");
    }

    const livePosition = this.snapshot.positions.find(
      (position) => position.symbol === safeSymbol,
    );

    if (!livePosition || livePosition.shares <= 0) {
      return this.failSubmit(`No live position found for ${safeSymbol}.`);
    }

    const qty = Math.min(closeShares, roundShares(livePosition.shares));
    const side: AlpacaSide = livePosition.side === "long" ? "sell" : "buy";

    this.setSnapshot({
      status: "loading",
      action: "closing-position",
      loading: true,
      lastError: null,
      lastMessage: `Closing ${qty} shares of ${safeSymbol}...`,
    });

    try {
      const order = await placeAlpacaOrder({
        mode: this.mode,
        symbol: safeSymbol,
        side,
        qty,
        type: "market",
        time_in_force: "day",
        extended_hours: Boolean(options?.extendedHours ?? true),
      });

      this.setSnapshot({
        status: "success",
        action: "idle",
        loading: false,
        connectionStatus: "connected",
        lastError: null,
        lastMessage: `Close order submitted for ${qty} ${safeSymbol}.`,
      });

      this.queueRefresh();

      return {
        ok: true,
        order,
      };
    } catch (error) {
      return this.failSubmit(this.errorToMessage(error));
    }
  }

  async closePositionPercent(
    symbol: string,
    percent: number,
    options?: ClosePositionOptions,
  ): Promise<SubmitQuickOrderResult> {
    const safeSymbol = cleanSymbol(symbol);
    const livePosition = this.snapshot.positions.find(
      (position) => position.symbol === safeSymbol,
    );

    if (!livePosition || livePosition.shares <= 0) {
      return this.failSubmit(`No live position found for ${safeSymbol}.`);
    }

    const safePercent = Math.max(0, Math.min(100, Number(percent) || 0));
    const shares = roundShares((livePosition.shares * safePercent) / 100);

    return this.closePositionShares(safeSymbol, shares, options);
  }

  async closePosition(
    symbol: string,
    options?: ClosePositionOptions,
  ): Promise<SubmitQuickOrderResult> {
    return this.closePositionPercent(symbol, 100, options);
  }

  async flattenAllPositions(
    options?: ClosePositionOptions,
  ): Promise<FlattenPositionsResult> {
    const positions = this.snapshot.positions.filter(
      (position) => position.shares > 0,
    );

    if (positions.length === 0) {
      const error = "No live positions to flatten.";
      this.setSnapshot({
        status: "error",
        action: "idle",
        loading: false,
        lastError: error,
        lastMessage: null,
      });

      return {
        ok: false,
        results: [],
        error,
      };
    }

    this.setSnapshot({
      status: "loading",
      action: "flattening-positions",
      loading: true,
      lastError: null,
      lastMessage: `Flattening ${positions.length} positions...`,
    });

    const results: SubmitQuickOrderResult[] = [];

    for (const position of positions) {
      const side: AlpacaSide = position.side === "long" ? "sell" : "buy";
      const qty = roundShares(position.shares);

      try {
        const order = await placeAlpacaOrder({
          mode: this.mode,
          symbol: position.symbol,
          side,
          qty,
          type: "market",
          time_in_force: "day",
          extended_hours: Boolean(options?.extendedHours ?? true),
        });

        results.push({
          ok: true,
          order,
        });
      } catch (error) {
        results.push({
          ok: false,
          error: this.errorToMessage(error),
        });
      }
    }

    const failed = results.filter((result) => !result.ok);
    const ok = failed.length === 0;

    this.setSnapshot({
      status: ok ? "success" : "error",
      action: "idle",
      loading: false,
      lastError: ok ? null : failed[0]?.error ?? "One or more flatten orders failed.",
      lastMessage: ok
        ? `Flatten orders submitted for ${positions.length} positions.`
        : "One or more flatten orders failed.",
    });

    this.queueRefresh();

    return {
      ok,
      results,
      error: ok ? undefined : failed[0]?.error,
    };
  }

  async cancelOrder(orderId: string): Promise<boolean> {
    if (!orderId) return false;

    this.setSnapshot({
      status: "loading",
      action: "canceling-order",
      loading: true,
      lastError: null,
      lastMessage: "Canceling order...",
    });

    try {
      await cancelAlpacaOrder(orderId, this.mode);

      this.setSnapshot({
        status: "success",
        action: "idle",
        loading: false,
        lastError: null,
        lastMessage: "Order canceled.",
      });

      this.queueRefresh();
      return true;
    } catch (error) {
      this.setSnapshot({
        status: "error",
        action: "idle",
        loading: false,
        lastError: this.errorToMessage(error),
        lastMessage: null,
      });

      return false;
    }
  }

  async modifyOrder(
    orderId: string,
    patch: {
      qty?: number;
      limit_price?: number;
      stop_price?: number;
      time_in_force?: string;
    },
  ): Promise<any | null> {
    if (!orderId) return null;

    this.setSnapshot({
      status: "loading",
      action: "modifying-order",
      loading: true,
      lastError: null,
      lastMessage: "Updating order...",
    });

    try {
      const updated = await updateAlpacaOrder(orderId, {
        ...patch,
        limit_price:
          patch.limit_price !== undefined
            ? roundToTick(patch.limit_price)
            : undefined,
        stop_price:
          patch.stop_price !== undefined
            ? roundToTick(patch.stop_price)
            : undefined,
      }, this.mode);

      this.setSnapshot({
        status: "success",
        action: "idle",
        loading: false,
        lastError: null,
        lastMessage: "Order updated.",
      });

      this.queueRefresh();
      return updated;
    } catch (error) {
      this.setSnapshot({
        status: "error",
        action: "idle",
        loading: false,
        lastError: this.errorToMessage(error),
        lastMessage: null,
      });

      return null;
    }
  }

  private failSubmit(error: string): SubmitQuickOrderResult {
    this.setSnapshot({
      status: "error",
      action: "idle",
      loading: false,
      lastError: error,
      lastMessage: null,
    });

    return {
      ok: false,
      error,
    };
  }

  private errorToMessage(error: unknown): string {
    if (error instanceof Error) return error.message;
    if (typeof error === "string") return error;
    return "Unknown trading execution error.";
  }

  private setSnapshot(patch: Partial<TradeExecutionSnapshot>): void {
    this.snapshot = {
      ...this.snapshot,
      ...patch,
    };

    for (const listener of this.listeners) {
      listener(this.snapshot);
    }
  }
}

let sharedTradeExecutionService: TradeExecutionService | null = null;

export function getSharedTradeExecutionService(
  mode: AlpacaMode = "paper",
): TradeExecutionService {
  if (!sharedTradeExecutionService) {
    sharedTradeExecutionService = new TradeExecutionService(mode);
  } else {
    sharedTradeExecutionService.setMode(mode);
  }

  return sharedTradeExecutionService;
}