import type {
  FilledOrderState,
  JournalTradeState,
  PerformanceSnapshot,
  TradeHistoryEntry,
} from "../../components/chart/right-panel/workspaces/trading/TradingTypes";

export class TradeHistoryEngine {
  private filledOrders: FilledOrderState[] = [];
  private tradeHistory: TradeHistoryEntry[] = [];

  setFilledOrders(orders: FilledOrderState[]): void {
    this.filledOrders = [...orders];
    this.rebuildHistory();
  }

  addFilledOrder(order: FilledOrderState): void {
    this.filledOrders.unshift(order);
    this.rebuildHistory();
  }

  getFilledOrders(): FilledOrderState[] {
    return this.filledOrders;
  }

  getTradeHistory(): TradeHistoryEntry[] {
    return this.tradeHistory;
  }

  getJournal(): JournalTradeState[] {
    return this.tradeHistory.map((trade) => ({
      id: trade.id,
      date: trade.entryTime.split(" ")[0] ?? "",
      time: trade.entryTime.split(" ")[1] ?? "",
      symbol: trade.symbol,
      strategy: "",
      side: trade.side,
      shares: trade.shares,
      entry: trade.entryPrice,
      exit: trade.exitPrice,
      target: 0,
      stop: 0,
      exitReason: trade.exitReason,
      holdTime: "",
      grossPnl: trade.grossPnl,
      netPnl: trade.netPnl,
      rMultiple: trade.rMultiple,
      notes: trade.notes,
    }));
  }

  getPerformance(): PerformanceSnapshot {
    const closed = this.tradeHistory.filter(
      (trade) => trade.status === "closed",
    );

    const wins = closed.filter((trade) => trade.netPnl > 0);
    const losses = closed.filter((trade) => trade.netPnl < 0);

    const grossProfit = wins.reduce((sum, trade) => sum + trade.netPnl, 0);

    const grossLoss = Math.abs(
      losses.reduce((sum, trade) => sum + trade.netPnl, 0),
    );

    const netPnl = closed.reduce((sum, trade) => sum + trade.netPnl, 0);

    return {
      totalTrades: this.tradeHistory.length,
      closedTrades: closed.length,
      openTrades: this.tradeHistory.length - closed.length,

      wins: wins.length,
      losses: losses.length,

      winRate:
        closed.length > 0 ? (wins.length / closed.length) * 100 : 0,

      grossProfit,
      grossLoss,
      netPnl,

      profitFactor:
        grossLoss > 0 ? grossProfit / grossLoss : grossProfit,

      expectancy:
        closed.length > 0 ? netPnl / closed.length : 0,

      averageWinner:
        wins.length > 0 ? grossProfit / wins.length : 0,

      averageLoser:
        losses.length > 0 ? grossLoss / losses.length : 0,

      averageR:
        closed.length > 0
          ? closed.reduce((sum, trade) => sum + trade.rMultiple, 0) /
            closed.length
          : 0,

      largestWinner:
        wins.length > 0
          ? Math.max(...wins.map((trade) => trade.netPnl))
          : 0,

      largestLoser:
        losses.length > 0
          ? Math.min(...losses.map((trade) => trade.netPnl))
          : 0,
    };
  }

  private rebuildHistory(): void {
    this.tradeHistory = this.filledOrders.map((order) => ({
      id: order.id,
      symbol: order.symbol,

      side: order.side,

      positionSide:
        order.side === "buy" ? "long" : "short",

      status: "closed",

      shares: order.shares,
      openShares: 0,

      entryPrice: order.averageFillPrice,
      exitPrice: order.averageFillPrice,

      entryTime: order.filledAt,
      exitTime: order.filledAt,

      grossPnl: 0,
      netPnl: 0,

      commission: 0,

      rMultiple: 0,

      exitReason: "unknown",

      sourceOrderIds: [order.orderId],

      notes: "",

      rawOrders: order.raw ? [order.raw] : [],
    }));
  }
}

let sharedTradeHistoryEngine: TradeHistoryEngine | null = null;

export function getSharedTradeHistoryEngine(): TradeHistoryEngine {
  if (!sharedTradeHistoryEngine) {
    sharedTradeHistoryEngine = new TradeHistoryEngine();
  }

  return sharedTradeHistoryEngine;
}