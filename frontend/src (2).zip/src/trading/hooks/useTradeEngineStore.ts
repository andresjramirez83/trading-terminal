// src/trading/hooks/useTradeEngineStore.ts

import { useCallback, useEffect, useMemo, useState } from "react";
import { getSharedTradeEngine } from "../engine/TradeEngineRuntime";
import type { TradeDirection, TradeObject } from "../engine/TradeTypes";
import {
  getSharedTradeExecutionService,
  type TradeExecutionSnapshot,
} from "../services/TradeExecutionService";
import { calculateQuickOrderEstimate } from "../../components/chart/right-panel/workspaces/trading/OrderCalculator";
import { getSharedPositionProtectionEngine } from "../position/PositionProtectionEngine";
import type {
  CurrentPositionState,
  CurrentPositionStats,
  JournalTradeState,
  OpenOrderState,
  QuickOrderState,
  TradePlanState,
  TradePlanStats,
} from "../../components/chart/right-panel/workspaces/trading/TradingTypes";

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function safeNumber(value: unknown): number {
  const next = Number(value);
  return Number.isFinite(next) ? next : 0;
}

function nullableNumber(value: unknown): number | null {
  const next = Number(value);
  return Number.isFinite(next) && next > 0 ? next : null;
}

function emptyPosition(symbol: string): CurrentPositionState {
  return {
    symbol,
    side: "long",
    shares: 0,
    entry: 0,
    target: 0,
    stop: 0,
  };
}

function tradeToPlan(
  trade: TradeObject | null,
  symbol: string,
): TradePlanState {
  return {
    symbol,
    side: trade?.direction ?? "long",
    entry: safeNumber(trade?.entry),
    target: safeNumber(trade?.targets[0]?.price),
    stop: safeNumber(trade?.stop),
    shares: safeNumber(trade?.shares ?? trade?.metrics.estimatedShares ?? 100),
  };
}

function calculateTradePlanStats(
  plan: TradePlanState,
  currentPrice: number,
): TradePlanStats {
  const activeEntry = plan.entry > 0 ? plan.entry : currentPrice;

  const riskPerShare =
    plan.side === "long"
      ? Math.max(0, activeEntry - plan.stop)
      : Math.max(0, plan.stop - activeEntry);

  const rewardPerShare =
    plan.side === "long"
      ? Math.max(0, plan.target - activeEntry)
      : Math.max(0, activeEntry - plan.target);

  const totalRisk = riskPerShare * plan.shares;
  const totalReward = rewardPerShare * plan.shares;
  const rMultiple = totalRisk > 0 ? totalReward / totalRisk : 0;

  return {
    activeEntry: safeNumber(activeEntry),
    riskPerShare: safeNumber(riskPerShare),
    rewardPerShare: safeNumber(rewardPerShare),
    totalRisk: safeNumber(totalRisk),
    totalReward: safeNumber(totalReward),
    rMultiple: safeNumber(rMultiple),
  };
}

function calculateCurrentPositionStats(
  position: CurrentPositionState,
  currentPrice: number,
): CurrentPositionStats {
  const activeEntry = position.entry > 0 ? position.entry : currentPrice;

  const pnlPerShare =
    position.side === "long"
      ? currentPrice - activeEntry
      : activeEntry - currentPrice;

  const unrealizedPnl = pnlPerShare * position.shares;

  const riskPerShare =
    position.side === "long"
      ? Math.max(0, activeEntry - position.stop)
      : Math.max(0, position.stop - activeEntry);

  const currentR = riskPerShare > 0 ? pnlPerShare / riskPerShare : 0;

  const targetDistance =
    position.side === "long"
      ? position.target - activeEntry
      : activeEntry - position.target;

  const currentDistance =
    position.side === "long"
      ? currentPrice - activeEntry
      : activeEntry - currentPrice;

  const progressToTarget =
    targetDistance > 0
      ? clamp((currentDistance / targetDistance) * 100, 0, 100)
      : 0;

  return {
    activeEntry: safeNumber(activeEntry),
    pnlPerShare: safeNumber(pnlPerShare),
    unrealizedPnl: safeNumber(unrealizedPnl),
    riskPerShare: safeNumber(riskPerShare),
    currentR: safeNumber(currentR),
    progressToTarget: safeNumber(progressToTarget),
  };
}

function findPositionForSymbol(
  positions: CurrentPositionState[],
  symbol: string,
): CurrentPositionState {
  const safeSymbol = symbol.trim().toUpperCase();

  return (
    positions.find((position) => position.symbol === safeSymbol) ??
    emptyPosition(safeSymbol)
  );
}

export function useTradeEngineStore(symbol: string, currentPrice: number) {
  const safeSymbol = (symbol || "—").trim().toUpperCase();
  const tradeEngine = getSharedTradeEngine();
  const executionService = getSharedTradeExecutionService("paper");
  const protectionEngine = getSharedPositionProtectionEngine();

  const [selectedTrade, setSelectedTrade] = useState<TradeObject | null>(() =>
    tradeEngine.getSelectedTrade(),
  );

  const [tradePlanDraft, setTradePlanDraft] = useState<TradePlanState>(() =>
    tradeToPlan(tradeEngine.getSelectedTrade(), safeSymbol),
  );

  const [executionSnapshot, setExecutionSnapshot] =
    useState<TradeExecutionSnapshot>(() => executionService.getSnapshot());

  const [quickOrder, setQuickOrder] = useState<QuickOrderState>({
    symbol: safeSymbol,
    side: "buy",
    sizingMode: "dollars",
    shares: 100,
    dollars: 1000,
    orderType: "market",
    limitPrice: 0,
    stopPrice: 0,
    extendedHours: true,
    bracketEnabled: true,
    bracketTarget: 0,
    bracketStop: 0,
  });

  const [positionDraft, setPositionDraft] = useState<CurrentPositionState>(() =>
    emptyPosition(safeSymbol),
  );

  const [journalTrades] = useState<JournalTradeState[]>([]);

  useEffect(() => {
    const syncSelectedTrade = () => {
      const nextTrade = tradeEngine.getSelectedTrade();
      setSelectedTrade(nextTrade);
      setTradePlanDraft(tradeToPlan(nextTrade, safeSymbol));
    };

    syncSelectedTrade();

    return tradeEngine.events.subscribe((event) => {
      if (
        event.type === "trade-created" ||
        event.type === "trade-updated" ||
        event.type === "trade-selected" ||
        event.type === "trade-deleted" ||
        event.type === "registry-reset"
      ) {
        syncSelectedTrade();
      }
    });
  }, [safeSymbol, tradeEngine]);

  useEffect(() => {
    const unsubscribe = executionService.subscribe(setExecutionSnapshot);
    executionService.startPolling(8000);

    return () => {
      unsubscribe();
    };
  }, [executionService]);

  useEffect(() => {
    setQuickOrder((current) => ({
      ...current,
      symbol: safeSymbol,
    }));

    setPositionDraft((current) => ({
      ...current,
      symbol: safeSymbol,
    }));

    setTradePlanDraft((current) => ({
      ...current,
      symbol: safeSymbol,
    }));
  }, [safeSymbol]);

  const tradePlan = tradePlanDraft;

  const livePosition = useMemo(
    () => findPositionForSymbol(executionSnapshot.positions, safeSymbol),
    [executionSnapshot.positions, safeSymbol],
  );

  const positionProtection = useMemo(() => {
    if (livePosition.shares <= 0) return null;

    return protectionEngine.buildProtection(
      {
        ...livePosition,
        stop: positionDraft.stop,
        target: positionDraft.target,
      },
      executionSnapshot.openOrders,
    );
  }, [
    executionSnapshot.openOrders,
    livePosition,
    positionDraft.stop,
    positionDraft.target,
    protectionEngine,
  ]);

  const currentPosition = useMemo<CurrentPositionState>(() => {
    if (positionProtection) {
      return positionProtection.position;
    }

    return {
      ...positionDraft,
      symbol: safeSymbol,
    };
  }, [positionDraft, positionProtection, safeSymbol]);

  const openOrders = useMemo<OpenOrderState[]>(
    () =>
      executionSnapshot.openOrders.filter(
        (order) => order.symbol === safeSymbol || safeSymbol === "—",
      ),
    [executionSnapshot.openOrders, safeSymbol],
  );

  const updateTradePlan = useCallback(
    (patch: Partial<TradePlanState>) => {
      const nextPlan: TradePlanState = {
        ...tradePlanDraft,
        ...patch,
        symbol: safeSymbol,
      };

      setTradePlanDraft(nextPlan);

      let trade = tradeEngine.getSelectedTrade();

      if (!trade) {
        trade = tradeEngine.createTrade({
          symbol: safeSymbol,
          direction: nextPlan.side as TradeDirection,
          source: "manual",
          mode: "paper",
          status: "draft",
          entry:
            nullableNumber(nextPlan.entry) ??
            (currentPrice > 0 ? currentPrice : null),
          stop: nullableNumber(nextPlan.stop),
          target: nullableNumber(nextPlan.target),
          sizingMode: "shares",
          shares: nullableNumber(nextPlan.shares) ?? 100,
        });

        tradeEngine.selectTrade(trade.id);
        return;
      }

      if (patch.side !== undefined) {
        tradeEngine.updateTrade(trade.id, {
          direction: nextPlan.side as TradeDirection,
        });
      }

      if (patch.entry !== undefined) {
        tradeEngine.updateEntry(trade.id, nullableNumber(nextPlan.entry));
      }

      if (patch.stop !== undefined) {
        tradeEngine.updateStop(trade.id, nullableNumber(nextPlan.stop));
      }

      if (patch.target !== undefined) {
        tradeEngine.updateTarget(trade.id, nullableNumber(nextPlan.target));
      }

      if (patch.shares !== undefined) {
        tradeEngine.updateTrade(trade.id, {
          sizingMode: "shares",
          shares: nullableNumber(nextPlan.shares),
        });
      }
    },
    [currentPrice, safeSymbol, tradeEngine, tradePlanDraft],
  );

  const updateQuickOrder = useCallback(
    (patch: Partial<QuickOrderState>) => {
      setQuickOrder((current) => ({
        ...current,
        ...patch,
        symbol: safeSymbol,
      }));
    },
    [safeSymbol],
  );

  const updateCurrentPosition = useCallback(
    (patch: Partial<CurrentPositionState>) => {
      setPositionDraft((current) => ({
        ...current,
        ...patch,
        symbol: safeSymbol,
      }));

      if (patch.stop !== undefined && positionProtection?.stopOrderId) {
        void executionService.modifyOrder(positionProtection.stopOrderId, {
          stop_price: patch.stop,
        });
      }

      if (patch.target !== undefined && positionProtection?.targetOrderId) {
        void executionService.modifyOrder(positionProtection.targetOrderId, {
          limit_price: patch.target,
        });
      }
    },
    [executionService, positionProtection, safeSymbol],
  );

  const syncPlanToOrder = useCallback(() => {
    setQuickOrder((current) => ({
      ...current,
      symbol: safeSymbol,
      side: tradePlan.side === "long" ? "buy" : "sell",
      sizingMode: "shares",
      shares: tradePlan.shares,
      bracketEnabled: true,
      bracketTarget: tradePlan.target,
      bracketStop: tradePlan.stop,
      limitPrice: tradePlan.entry,
      orderType: tradePlan.entry > 0 ? "limit" : "market",
    }));
  }, [safeSymbol, tradePlan]);

  const syncPlanToPosition = useCallback(() => {
    setPositionDraft({
      symbol: safeSymbol,
      side: tradePlan.side,
      shares: tradePlan.shares,
      entry: tradePlan.entry,
      target: tradePlan.target,
      stop: tradePlan.stop,
    });
  }, [safeSymbol, tradePlan]);

  const moveStopToBreakEven = useCallback(() => {
    const breakEvenPrice =
      currentPosition.entry > 0 ? currentPosition.entry : currentPrice;

    setPositionDraft((current) => ({
      ...current,
      stop: breakEvenPrice,
    }));

    if (positionProtection?.stopOrderId && breakEvenPrice > 0) {
      void executionService.modifyOrder(positionProtection.stopOrderId, {
        stop_price: breakEvenPrice,
      });
    }
  }, [
    currentPosition.entry,
    currentPrice,
    executionService,
    positionProtection,
  ]);

  const submitQuickOrder = useCallback(
    async (estimatedShares: number) => {
      if (estimatedShares <= 0) return;

      const estimate = calculateQuickOrderEstimate(
        {
          ...quickOrder,
          symbol: safeSymbol,
          shares:
            quickOrder.sizingMode === "shares"
              ? estimatedShares
              : quickOrder.shares,
        },
        currentPrice,
      );

      await executionService.submitQuickOrder(
        {
          ...quickOrder,
          symbol: safeSymbol,
        },
        {
          ...estimate,
          estimatedShares,
        },
      );
    },
    [currentPrice, executionService, quickOrder, safeSymbol],
  );

  const submitTradePlan = useCallback(async () => {
    const shares = Math.max(0, Math.floor(Number(tradePlan.shares) || 0));

    if (shares <= 0) {
      return;
    }

    const plannedOrder: QuickOrderState = {
      symbol: safeSymbol,
      side: tradePlan.side === "long" ? "buy" : "sell",
      sizingMode: "shares",
      shares,
      dollars: 0,
      orderType: tradePlan.entry > 0 ? "limit" : "market",
      limitPrice: tradePlan.entry,
      stopPrice: 0,
      extendedHours: false,
      bracketEnabled: tradePlan.target > 0 || tradePlan.stop > 0,
      bracketTarget: tradePlan.target,
      bracketStop: tradePlan.stop,
    };

    const estimate = calculateQuickOrderEstimate(plannedOrder, currentPrice);

    await executionService.submitQuickOrder(plannedOrder, {
      ...estimate,
      estimatedShares: shares,
    });
  }, [currentPrice, executionService, safeSymbol, tradePlan]);

  const cancelOpenOrder = useCallback(
    async (orderId: string) => {
      await executionService.cancelOrder(orderId);
    },
    [executionService],
  );

  const fillOpenOrder = useCallback((_orderId: string) => {
    // Real fills come from Alpaca after the execution service refreshes.
  }, []);

  const refreshTradingData = useCallback(() => {
    executionService.queueRefresh();
  }, [executionService]);

  const closePosition = useCallback(async () => {
    await executionService.closePosition(safeSymbol, {
      extendedHours: quickOrder.extendedHours,
    });
  }, [executionService, quickOrder.extendedHours, safeSymbol]);

  const closePositionPercent = useCallback(
    async (percent: number) => {
      await executionService.closePositionPercent(safeSymbol, percent, {
        extendedHours: quickOrder.extendedHours,
      });
    },
    [executionService, quickOrder.extendedHours, safeSymbol],
  );

  const closePositionShares = useCallback(
    async (shares: number) => {
      await executionService.closePositionShares(safeSymbol, shares, {
        extendedHours: quickOrder.extendedHours,
      });
    },
    [executionService, quickOrder.extendedHours, safeSymbol],
  );

  const flattenAllPositions = useCallback(async () => {
    await executionService.flattenAllPositions({
      extendedHours: quickOrder.extendedHours,
    });
  }, [executionService, quickOrder.extendedHours]);

  const tradePlanStats = useMemo(
    () => calculateTradePlanStats(tradePlan, currentPrice),
    [tradePlan, currentPrice],
  );

  const currentPositionStats = useMemo(
    () => calculateCurrentPositionStats(currentPosition, currentPrice),
    [currentPosition, currentPrice],
  );

  return useMemo(
    () => ({
      account: executionSnapshot.account,

      tradePlan: { ...tradePlan, symbol: safeSymbol },
      tradePlanStats,
      updateTradePlan,
      syncPlanToOrder,
      syncPlanToPosition,
      submitTradePlan,

      quickOrder: { ...quickOrder, symbol: safeSymbol },
      updateQuickOrder,
      submitQuickOrder,

      currentPosition: { ...currentPosition, symbol: safeSymbol },
      currentPositionStats,
      positionProtection,
      updateCurrentPosition,
      moveStopToBreakEven,
      closePosition,
      closePositionPercent,
      closePositionShares,
      flattenAllPositions,

      openOrders,
      cancelOpenOrder,
      fillOpenOrder,

      journalTrades,
      selectedTrade,
      hasSelectedTrade: Boolean(selectedTrade),

      connectionStatus: executionSnapshot.connectionStatus,
      executionStatus: executionSnapshot.status,
      executionAction: executionSnapshot.action,
      executionLoading: executionSnapshot.loading,
      executionError: executionSnapshot.lastError,
      executionMessage: executionSnapshot.lastMessage,
      executionRefreshCount: executionSnapshot.refreshCount,
      executionUpdatedAt: executionSnapshot.updatedAt,
      refreshTradingData,
    }),
    [
      cancelOpenOrder,
      closePosition,
      closePositionPercent,
      closePositionShares,
      currentPosition,
      currentPositionStats,
      executionSnapshot.account,
      executionSnapshot.action,
      executionSnapshot.connectionStatus,
      executionSnapshot.lastError,
      executionSnapshot.lastMessage,
      executionSnapshot.loading,
      executionSnapshot.refreshCount,
      executionSnapshot.status,
      executionSnapshot.updatedAt,
      fillOpenOrder,
      flattenAllPositions,
      journalTrades,
      moveStopToBreakEven,
      openOrders,
      positionProtection,
      quickOrder,
      refreshTradingData,
      safeSymbol,
      selectedTrade,
      submitQuickOrder,
      submitTradePlan,
      syncPlanToOrder,
      syncPlanToPosition,
      tradePlan,
      tradePlanStats,
      updateCurrentPosition,
      updateQuickOrder,
      updateTradePlan,
    ],
  );
}