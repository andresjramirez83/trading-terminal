import { useEffect, useMemo, useState } from "react";
import { getSharedTradeExecutionService } from "../services/TradeExecutionService";
import type { TradeExecutionSnapshot } from "../services/TradeExecutionService";

export function useTradeHistoryStore() {
  const executionService = getSharedTradeExecutionService("paper");

  const [snapshot, setSnapshot] = useState<TradeExecutionSnapshot>(() =>
    executionService.getSnapshot(),
  );

  useEffect(() => {
    return executionService.subscribe(setSnapshot);
  }, [executionService]);

  return useMemo(
    () => ({
      filledOrders: snapshot.filledOrders,
      tradeHistory: snapshot.tradeHistory,
      performance: snapshot.performance,
      connectionStatus: snapshot.connectionStatus,
      loading: snapshot.loading,
      updatedAt: snapshot.updatedAt,
    }),
    [snapshot],
  );
}