// src/trading/controller/ChartTradeBridge.ts

import { DrawingEngine } from "../../components/chart/DrawingEngine";
import type {
  ChartDrawing,
  LongPositionDrawing,
} from "../../components/chart/DrawingTypes";
import { TradeEngine } from "../engine/TradeEngine";

function isLongPosition(drawing: ChartDrawing): drawing is LongPositionDrawing {
  return drawing.type === "longPosition";
}

function getNewestLongPosition(drawings: ChartDrawing[]): LongPositionDrawing | null {
  for (let index = drawings.length - 1; index >= 0; index -= 1) {
    const drawing = drawings[index];
    if (isLongPosition(drawing)) return drawing;
  }

  return null;
}

function getSelectedLongPosition(
  drawings: ChartDrawing[],
  selectedDrawingId: string | null,
): LongPositionDrawing | null {
  if (!selectedDrawingId) return null;

  const drawing = drawings.find((item) => item.id === selectedDrawingId);
  return drawing && isLongPosition(drawing) ? drawing : null;
}

function getActiveLongPosition(
  drawings: ChartDrawing[],
  selectedDrawingId: string | null,
): LongPositionDrawing | null {
  return getSelectedLongPosition(drawings, selectedDrawingId) ?? getNewestLongPosition(drawings);
}

function finiteNumber(value: unknown): number | null {
  const next = Number(value);
  return Number.isFinite(next) ? next : null;
}

function targetPrice(drawing: LongPositionDrawing): number | null {
  return finiteNumber(drawing.target.price);
}

export class ChartTradeBridge {
  private unsubscribeDrawings: (() => void) | null = null;
  private syncing = false;
  private lastDrawingIds = new Set<string>();

  constructor(
    private readonly drawingEngine: DrawingEngine,
    private readonly tradeEngine: TradeEngine,
  ) {}

  attach(): void {
    if (this.unsubscribeDrawings) return;

    this.unsubscribeDrawings = this.drawingEngine.subscribeDrawings(
      (drawings, reason) => {
        if (this.syncing) return;

        this.syncing = true;
        try {
          this.handleDrawingsChanged(drawings, reason);
        } finally {
          this.syncing = false;
        }
      },
    );
  }

  detach(): void {
    this.unsubscribeDrawings?.();
    this.unsubscribeDrawings = null;
    this.lastDrawingIds.clear();
  }

  runMuted(action: () => void): void {
    this.syncing = true;
    try {
      action();
    } finally {
      this.syncing = false;
    }
  }

  private handleDrawingsChanged(drawings: ChartDrawing[], reason: string): void {
    if (reason === "clear" || drawings.length === 0) {
      this.lastDrawingIds.clear();
      this.tradeEngine.selectTrade(null);
      return;
    }

    if (reason === "remove") {
      this.deleteTradesForRemovedDrawings(drawings);
    }

    if (reason === "duplicate") {
      this.handleDuplicatedLongPosition(drawings);
      this.lastDrawingIds = new Set(this.drawingEngine.getDrawings().map((drawing) => drawing.id));
      return;
    }

    for (const drawing of drawings) {
      if (isLongPosition(drawing)) {
        this.syncLongPositionToTrade(drawing);
      }
    }

    this.selectActiveTradeFromDrawing();
    this.lastDrawingIds = new Set(this.drawingEngine.getDrawings().map((drawing) => drawing.id));
  }

  private syncLongPositionToTrade(drawing: LongPositionDrawing): string | null {
    const entry = finiteNumber(drawing.entry.price);
    const stop = finiteNumber(drawing.stop.price);
    const target = targetPrice(drawing);

    if (entry == null || stop == null || target == null) return drawing.tradeId ?? null;

    if (!drawing.tradeId) {
      const workspace = this.tradeEngine.getWorkspace();
      const trade = this.tradeEngine.createTrade({
        symbol: workspace.symbol ?? "SPY",
        timeframe: workspace.timeframe,
        direction: "long",
        source: "manual",
        mode: "paper",
        status: "draft",
        entry,
        stop,
        target,
        drawingId: drawing.id,
        sizingMode: "risk",
        riskAmount: 100,
        shares: 100,
      });

      this.drawingEngine.linkLongPositionToTrade(drawing.id, trade.id);
      this.tradeEngine.selectTrade(trade.id);
      return trade.id;
    }

    const existingTrade = this.tradeEngine.getTrade(drawing.tradeId);

    if (!existingTrade) {
      const workspace = this.tradeEngine.getWorkspace();
      const trade = this.tradeEngine.createTrade({
        symbol: workspace.symbol ?? "SPY",
        timeframe: workspace.timeframe,
        direction: "long",
        source: "manual",
        mode: "paper",
        status: "draft",
        entry,
        stop,
        target,
        drawingId: drawing.id,
        sizingMode: "risk",
        riskAmount: 100,
        shares: 100,
      });

      this.drawingEngine.linkLongPositionToTrade(drawing.id, trade.id);
      this.tradeEngine.selectTrade(trade.id);
      return trade.id;
    }

    this.tradeEngine.updateTrade(drawing.tradeId, {
      entry,
      stop,
      direction: "long",
      links: {
        ...existingTrade.links,
        drawingId: drawing.id,
      },
    });

    this.tradeEngine.updateTarget(drawing.tradeId, target);
    return drawing.tradeId;
  }

  private selectActiveTradeFromDrawing(): void {
    const drawings = this.drawingEngine.getDrawings();
    const selectedDrawingId = this.drawingEngine.getSelectedDrawingId();
    const activeLongPosition = getActiveLongPosition(drawings, selectedDrawingId);

    if (!activeLongPosition?.tradeId) return;

    if (this.tradeEngine.getSelectedTradeId() !== activeLongPosition.tradeId) {
      this.tradeEngine.selectTrade(activeLongPosition.tradeId);
    }
  }

  private deleteTradesForRemovedDrawings(drawings: ChartDrawing[]): void {
    const currentDrawingIds = new Set(drawings.map((drawing) => drawing.id));

    for (const previousId of this.lastDrawingIds) {
      if (currentDrawingIds.has(previousId)) continue;

      const trade = this.tradeEngine
        .getTrades()
        .find((item) => item.links.drawingId === previousId);

      if (trade) {
        this.tradeEngine.deleteTrade(trade.id);
      }
    }
  }

  private handleDuplicatedLongPosition(drawings: ChartDrawing[]): void {
    const newDrawing = drawings.find((drawing): drawing is LongPositionDrawing => {
      return isLongPosition(drawing) && !this.lastDrawingIds.has(drawing.id);
    });

    if (!newDrawing) {
      for (const drawing of drawings) {
        if (isLongPosition(drawing)) this.syncLongPositionToTrade(drawing);
      }
      this.selectActiveTradeFromDrawing();
      return;
    }

    const entry = finiteNumber(newDrawing.entry.price);
    const stop = finiteNumber(newDrawing.stop.price);
    const target = finiteNumber(newDrawing.target.price);
    const workspace = this.tradeEngine.getWorkspace();

    const trade = this.tradeEngine.createTrade({
      symbol: workspace.symbol ?? "SPY",
      timeframe: workspace.timeframe,
      direction: "long",
      source: "manual",
      mode: "paper",
      status: "draft",
      entry,
      stop,
      target,
      drawingId: newDrawing.id,
      sizingMode: "risk",
      riskAmount: 100,
      shares: 100,
    });

    this.drawingEngine.linkLongPositionToTrade(newDrawing.id, trade.id);
    this.tradeEngine.selectTrade(trade.id);
  }
}
