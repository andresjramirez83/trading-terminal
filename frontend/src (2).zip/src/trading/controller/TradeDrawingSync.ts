// src/trading/controller/TradeDrawingSync.ts

import { DrawingEngine } from "../../components/chart/DrawingEngine";
import { TradeEngine } from "../engine/TradeEngine";
import type { TradeEvent } from "../engine/TradeEvents";

export class TradeDrawingSync {
  private unsubscribeTrades: (() => void) | null = null;
  private syncing = false;

  constructor(
    private readonly drawingEngine: DrawingEngine,
    private readonly tradeEngine: TradeEngine,
  ) {}

  attach(): void {
    if (this.unsubscribeTrades) return;

    this.unsubscribeTrades = this.tradeEngine.events.subscribe((event) => {
      if (this.syncing) return;
      this.handleTradeEvent(event);
    });
  }

  detach(): void {
    this.unsubscribeTrades?.();
    this.unsubscribeTrades = null;
  }

  private handleTradeEvent(event: TradeEvent): void {
    if (event.type === "trade-updated") {
      this.syncTradeToDrawing(event);
      return;
    }

    if (event.type === "trade-selected") {
      this.selectLinkedDrawing(event);
      return;
    }

    if (event.type === "trade-deleted") {
      this.removeLinkedDrawing(event);
      return;
    }

    if (event.type === "registry-reset") {
      this.syncing = true;
      try {
        this.drawingEngine.selectDrawing(null);
      } finally {
        this.syncing = false;
      }
    }
  }

  private syncTradeToDrawing(event: TradeEvent): void {
    const trade = event.trade;
    if (!trade) return;

    const drawingId = trade.links.drawingId;
    if (!drawingId) return;

    this.syncing = true;
    try {
      const updatedDrawing = this.drawingEngine.updateLongPositionFromTrade({
        tradeId: trade.id,
        entry: trade.entry,
        stop: trade.stop,
        target: trade.targets[0]?.price ?? null,
      });

      if (!updatedDrawing) {
        return;
      }
    } finally {
      this.syncing = false;
    }
  }

  private selectLinkedDrawing(event: TradeEvent): void {
    const trade = event.trade;

    this.syncing = true;
    try {
      this.drawingEngine.selectDrawing(trade?.links.drawingId ?? null);
    } finally {
      this.syncing = false;
    }
  }

  private removeLinkedDrawing(event: TradeEvent): void {
    const drawingId = event.previousTrade?.links.drawingId;
    if (!drawingId) return;

    this.syncing = true;
    try {
      this.drawingEngine.removeDrawing(drawingId);
    } finally {
      this.syncing = false;
    }
  }
}
