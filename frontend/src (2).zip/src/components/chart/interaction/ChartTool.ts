// src/components/chart/interaction/ChartTool.ts

import type { ChartMouseEvent } from "./events/ChartMouseEvent";
import type { ToolContext } from "./ToolContext";

export type ChartToolId =
  | "select"
  | "focus-box"
  | "trendline"
  | "horizontal-line"
  | "rectangle"
  | "ray"
  | string;

export interface ChartTool {
  readonly id: ChartToolId;
  readonly label: string;

  activate?(context: ToolContext): void;
  deactivate?(context: ToolContext): void;

  onMouseDown?(event: ChartMouseEvent, context: ToolContext): boolean | void;
  onMouseMove?(event: ChartMouseEvent, context: ToolContext): boolean | void;
  onMouseUp?(event: ChartMouseEvent, context: ToolContext): boolean | void;
  onClick?(event: ChartMouseEvent, context: ToolContext): boolean | void;
  onDoubleClick?(event: ChartMouseEvent, context: ToolContext): boolean | void;
  onContextMenu?(event: ChartMouseEvent, context: ToolContext): boolean | void;
  onKeyDown?(event: KeyboardEvent, context: ToolContext): boolean | void;
  onCancel?(context: ToolContext): boolean | void;

  drawOverlay?(ctx: CanvasRenderingContext2D, context: ToolContext): void;
}
